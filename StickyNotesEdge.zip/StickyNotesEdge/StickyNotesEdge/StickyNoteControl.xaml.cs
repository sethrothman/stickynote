﻿using System.Windows;
using System.Windows.Controls;

namespace StickyNotesEdge
{
    public partial class StickyNoteControl : UserControl
    {
        public StickyNoteControl()
        {
            InitializeComponent();
        }

        public event RoutedEventHandler DeleteClicked;

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            DeleteClicked?.Invoke(this, new RoutedEventArgs());
        }
    }
}
