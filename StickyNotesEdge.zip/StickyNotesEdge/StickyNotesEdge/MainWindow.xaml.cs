﻿using Gma.System.MouseKeyHook;
using StickyNotesEdge.Models;
using System;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace StickyNotesEdge
{
    public partial class MainWindow : Window
    {
        private NoteManager _noteManager = new NoteManager();
        private bool _visible = false;
        private IKeyboardMouseEvents _globalHook;

        public MainWindow()
        {
            InitializeComponent();
            this.Visibility = Visibility.Hidden;

            // Hook up global mouse event listener
            _globalHook = Hook.GlobalEvents();
            _globalHook.MouseDownExt += GlobalHook_MouseDownExt;

            NotesPanel.ItemsSource = _noteManager.Notes.Select(n =>
            {
                var control = new StickyNoteControl { DataContext = n };
                control.DeleteClicked += (s, e) =>
                {
                    _noteManager.Notes.Remove(n);
                    _noteManager.Save();
                };
                return control;
            }).ToList();

            _noteManager.Notes.CollectionChanged += Notes_CollectionChanged;

            this.Left = 0;
            this.Width = SystemParameters.WorkArea.Width;
            this.Top = SystemParameters.WorkArea.Bottom - this.Height - 10;
        }

        private void Notes_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            // Simple refresh; in real app, use ObservableCollection binding
            NotesPanel.ItemsSource = _noteManager.Notes.Select(n =>
            {
                var control = new StickyNoteControl { DataContext = n };
                control.DeleteClicked += (s, ev) =>
                {
                    _noteManager.Notes.Remove(n);
                    _noteManager.Save();
                };
                return control;
            }).ToList();
        }

        public void ToggleShowHide()
        {
            if (_visible)
                HideWithAnimation();
            else
                ShowWithAnimation();
        }

        private void ShowWithAnimation()
        {
            this.Visibility = Visibility.Visible;
            var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(300));
            this.BeginAnimation(Window.OpacityProperty, fadeIn);
            _visible = true;
        }

        private void HideWithAnimation()
        {
            var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(300));
            fadeOut.Completed += (s, e) => this.Visibility = Visibility.Hidden;
            this.BeginAnimation(Window.OpacityProperty, fadeOut);
            _visible = false;
        }

        private void AddNote_Click(object sender, RoutedEventArgs e)
        {
            var note = new StickyNote { Text = "New note" };
            _noteManager.Notes.Add(note);
            _noteManager.Save();
        }

        private void DeleteNote_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Delete this note?", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No)
                return;

            if ((sender as Button)?.Tag is StickyNote note)
            {
                _noteManager.Notes.Remove(note);
                _noteManager.Save();
            }
        }

        private void GlobalHook_MouseDownExt(object? sender, MouseEventExtArgs e)
        {
            // Get taskbar/work area info
            var workArea = SystemParameters.WorkArea;
            //var screenHeight = SystemParameters.PrimaryScreenHeight;

            // Check if the mouse is physically BELOW the work area (i.e., over the taskbar or below)
            if (e.Y >= workArea.Bottom)
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Left)
                {
                    ShowWithAnimation();
                    e.Handled = true; // Optionally block further processing (not required)
                }
            }
            else if (this.IsVisible && e.Y < this.Top)
            {
                // If notes panel is visible and you click above it, hide it
                HideWithAnimation();
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            _globalHook.MouseDownExt -= GlobalHook_MouseDownExt;
            _globalHook.Dispose();
        }
    }
}
